=== min ===
Contributors: r3dm1ke
Requires at least: 5.0
Tested up to: 5.2
Requires PHP: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A minimalist, multi-purpose theme for Wordpress 5+.

== Description ==
Use this theme to focus attention on the content, not presentation. Capture ideas, not decorations. Be concise, not extra.

== Frequently Asked Questions ==

= I really like this theme, but I need %feature%. Can you implement it? =

Let me know in the reviews section and/or in github issues: https://github.com/r3dm1ke/min_theme_wp . I will add it
given I have time, or you can add it yourself and submit a pull request, this is an Open Source project.

== Changelog ==

= 1.0 =
* Initial release